----------------------------------------------------------------------
Thanks To :                                
- Allah Swt          
- My Parents       
- ZeeoneOfc        
- Penyedia Apikey
- Creator Bot Lainnya
- Pengguna Bot Yang Selalu Support
----------------------------------------------------------------------