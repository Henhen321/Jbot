const fs = require('fs')
const chalk = require('chalk')

global.domain = "https://" // Isi Domain Panel
global.apikey = 'ptla_AbcDEfGhiJklmnOpQRStuVwXyZ' // Isi Apikey Plta
global.capikey = 'ptlc_AbcDEfGhiJklmnOpQRStuVwXyZ' // Isi Apikey Pltc
global.docker = 'ghcr.io/parkervcp/yolks:nodejs_18' // Docker Sesuaikan Kaya Yang Ada Di Panel Kalian Create Server Manual Dulu Lihat Dockernya Apa Taruh Disini Kalo Sama Biarin Aja Gausah Diubah
global.namastorepanel = 'Kang Panel Gacor' // Ubah Terserah Mau Diisi Apa Nama Ini Buat Nama Yang Bakal Muncul Di List Server Sama List User
global.egg = "15"
global.loc = "1"

// Kalo Kurang Silahkan Sesuaiin Sendiri Sesuai Kebutuhan & Jualan Panel Kalian Sndri

global.gb1 = "1024"
global.cpu1 = "50"

global.gb2 = "2048"
global.cpu2 = "100"

global.gb3 = "3072"
global.cpu3 = "150"

global.gb4 = "4114"
global.cpu4 = "200"

global.gb5 = "5120"
global.cpu5 = "250"

global.gb6 = "6138"
global.cpu6 = "300"

global.gb7 = "7138"
global.cpu7 = "350"

global.gb8 = "8190"
global.cpu8 = "400"

global.gb9 = "9000"
global.cpu9 = "450"

global.gb10 = "10235"
global.cpu10 = "500"

